#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_espace_client_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajout_client_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modif_client_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_menu_employer_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_gestion_client_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer_modif_client_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_client_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_dadmin_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_dagent_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_dclient_clicked                     (GtkWidget       *objet_graphiquen,
                                        gpointer         user_data);
