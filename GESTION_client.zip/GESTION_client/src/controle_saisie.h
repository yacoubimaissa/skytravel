#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>





int controle_saisie_numtel(char x[15]);
int digital(char x[15]);
int controle_saisie_nonvide(char x[15]);
