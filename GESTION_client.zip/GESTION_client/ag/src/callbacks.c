#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verif.h"
#include "nour.h"
#include "string.h"



void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *input1;
	GtkWidget *input2;

	users u;

	int r=0;


	input1=lookup_widget(objet_graphique,"entry1");
	input2=lookup_widget(objet_graphique,"entry2");

	strcpy(u.log,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(u.pass,gtk_entry_get_text(GTK_ENTRY(input2)));
	
	r=verif(u);
	
	if (r==1)
	{	GtkWidget *admin;
		GtkWidget *aceuil;
		admin= create_admin ();
		gtk_widget_show (admin);
		aceuil=lookup_widget(objet_graphique,"aceuil");
		gtk_widget_destroy(aceuil);
	}	

	if (r==2)
	{	GtkWidget *aceuil;
		GtkWidget *client;
	 	client= create_client ();
  	        gtk_widget_show (client);
		aceuil=lookup_widget(objet_graphique,"aceuil");
		gtk_widget_destroy(aceuil);
		FILE* f;
			f=fopen("utilisateur.txt","w");
			fprintf(f,"%s  \n",u.log);
			fclose(f);
	}

	if (r==3)
	{	
		GtkWidget *aceuil;
		GtkWidget *agent;
	        agent= create_agent();
  	        gtk_widget_show (agent);
		aceuil=lookup_widget(objet_graphique,"aceuil");
		gtk_widget_destroy(aceuil);
	}
}


void
on_button50i_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ fact g;
factvol t;
res z;
resvol p;
FILE* f;
vol r;
int d;
char e[50];
GtkWidget *client ;
GtkWidget *input1;
GtkWidget *output1;
GtkWidget *n;

client=lookup_widget(objet_graphique,"client");
input1=lookup_widget(client,"entry1s");
output1=lookup_widget(client,"label1s");

n=lookup_widget(client,"spinbutton1s");

p.nbrp=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(n));

strcpy(e,gtk_entry_get_text(GTK_ENTRY(input1)));

p.id= iddd()+idddh()+iddde()-2;
p.r=rechercheduvol(e);


			f=fopen("utilisateur.txt","r");
			fscanf(f,"%s",p.login);
			fclose(f);

d=disponiblevol(p.r,p.nbrp);

if (d==1)
{
ajout_resvol_txt( p );
t.k=p;
t.pf=p.r.prixv*p.nbrp;
strcpy(t.type,"vol");
z.id=p.id;
 strcpy(z.type,"vol");
strcpy(z.login , p.login);
z.nbrp=p.nbrp;
g.id=p.id;
 strcpy(g.type,"vol");
strcpy(g.login , p.login);
g.pf=t.pf;
ajout_fact_txt(g);
ajout_res_txt(z);
ajout_factvol_txt(t);
gtk_label_set_text(GTK_LABEL(output1),"place disponible");}
else 
gtk_label_set_text(GTK_LABEL(output1),"place indisponible");

}


void
on_button2s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{fact g;
facthot t;
res z;
reshot h;
FILE* f;
hotel r;
int d,k;
char e[50];
GtkWidget *client ;
GtkWidget *input1;
GtkWidget *output1,*output2;
GtkWidget *n,*jj,*mm,*aa,*nnn;
client=lookup_widget(objet_graphique,"client");
input1=lookup_widget(client,"entry2s");
output1=lookup_widget(client,"label2s");
output2=lookup_widget(client,"label3s");
n=lookup_widget(client,"spinbutton2s");
jj=lookup_widget(client,"spinbutton10s");
mm=lookup_widget(client,"spinbutton11s");
aa=lookup_widget(client,"spinbutton12s");
nnn=lookup_widget(client,"spinbutton13s");
h.nbrp=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(n));
h.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jj));
h.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mm));
h.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(aa));
h.nn=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nnn));
strcpy(e,gtk_entry_get_text(GTK_ENTRY(input1)));
h.id= iddd()+idddh()+iddde()-2;
h.r=rechercheduhotel(e);
			f=fopen("utilisateur.txt","r");
			fscanf(f,"%s",h.login);
			fclose(f);
k=est_valide(h.j,h.m,h.a);
d=disponiblehot(h.r,h.nbrp);
if ((d==0)&&(k==0))
{gtk_label_set_text(GTK_LABEL(output1),"date non valide");
gtk_label_set_text(GTK_LABEL(output2),"place indisponible");}
else if (k==0)
{gtk_label_set_text(GTK_LABEL(output1),"date non valider");
gtk_label_set_text(GTK_LABEL(output2),"place disponible");}
else if (d==0)
{gtk_label_set_text(GTK_LABEL(output1),"date valide");
gtk_label_set_text(GTK_LABEL(output2),"place indisponible");}
else 
{gtk_label_set_text(GTK_LABEL(output1),"date valide");
ajout_reshot_txt( h );
t.k=h;
t.pf=h.r.prix*h.nn*h.nbrp;
strcpy(t.type,"hotel");
z.id=h.id;
 strcpy(z.type,"hotel");
strcpy(z.login , h.login);
z.nbrp=h.nbrp;
g.id=h.id;
 strcpy(g.type,"hotel");
strcpy(g.login , h.login);
g.pf=t.pf;
ajout_fact_txt(g);
ajout_res_txt(z);
ajout_facthot_txt(t);
gtk_label_set_text(GTK_LABEL(output2),"place disponible");}




}


void
on_button3s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{fact g;
factexc a;
res z;
resexc t;
FILE* f;
excursion r;
int d;
char e[50];
GtkWidget *client ;
GtkWidget *input1;
GtkWidget *output1;
GtkWidget *n;
client=lookup_widget(objet_graphique,"client");
input1=lookup_widget(client,"entry3s");
output1=lookup_widget(client,"label4s");
n=lookup_widget(client,"spinbutton3s");

t.nbrp=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(n));

strcpy(e,gtk_entry_get_text(GTK_ENTRY(input1)));

t.id= iddd()+idddh()+iddde()-2;
t.r=rechercheduexc(e);


			f=fopen("utilisateur.txt","r");
			fscanf(f,"%s",t.login);
			fclose(f);

d=disponibleexc(t.r,t.nbrp);

if (d==1)
{
ajout_resexc_txt( t );
a.k=t;
a.pf=t.r.prix*t.nbrp;
strcpy(a.type,"excursion");
z.id=t.id;
 strcpy(z.type,"excursion");
strcpy(z.login , t.login);
z.nbrp=t.nbrp;
g.id=t.id;
 strcpy(g.type,"excursion");
strcpy(g.login , t.login);
g.pf=a.pf;
ajout_fact_txt(g);
ajout_res_txt(z);
ajout_factexc_txt(a);
gtk_label_set_text(GTK_LABEL(output1),"place disponible");}
else 
gtk_label_set_text(GTK_LABEL(output1),"place indisponible");



}


void
on_button4s_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *client;
GtkWidget *notebook3;
GtkWidget *treeview1s;
client=lookup_widget(button,"client");
notebook3=lookup_widget(client,"notebook3");
treeview1s=lookup_widget(notebook3,"treeview1s");
afficher_reservation(treeview1s);
}

void
on_treeview1s_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 GtkWidget *modresv,*modrese,*modresh,*client,*notebook3;
GtkWidget *treeview1s,*input1;
gchar  *type[10] ,*login[20];
gint *id,*nbrp,*idd;
/*input1=lookup_widget(modresv,"entry1000s");*/
client=lookup_widget(objet_graphique,"client");
notebook3=lookup_widget(client,"notebook3");
modresv=create_modresv();
modresh=create_modresh();
modrese=create_modrese();
treeview1s=lookup_widget(notebook3,"treeview1s");

GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview1s));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&id,1,&type,2,&login,3,&nbrp,-1);
if (strcmp(*type,"vol")==0)
		  {gtk_window_set_position(GTK_WINDOW(client),GTK_WIN_POS_CENTER);
				gtk_widget_show(modresv);
/*gtk_entry_set_text(GTK_ENTRY (input1),_(id));*/
}
else if (strcmp(*type,"hotel")==0)
		 {gtk_window_set_position(GTK_WINDOW(client),GTK_WIN_POS_CENTER);
				gtk_widget_show(modresh);}
else
		{gtk_window_set_position(GTK_WINDOW(client),GTK_WIN_POS_CENTER);
				gtk_widget_show (modrese);}


}


void
on_button100s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *modresv ;
GtkWidget *client ;
client=lookup_widget(button,"client");
modresv=lookup_widget(button,"modresv");
gtk_widget_hide (modresv);
gtk_widget_show (client);
}


void
on_button101s_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{res z;
resvol p;
int d,i;
GtkWidget *modresv ;
GtkWidget *input1;
GtkWidget *output1;
GtkWidget *n;

modresv=lookup_widget(objet_graphique,"modresv");
input1=lookup_widget(modresv,"spinbutton1000s");
output1=lookup_widget(modresv,"label100s");
n=lookup_widget(modresv,"spinbutton100s");

i=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input1));

p= recherche_res_vol_id (i);

p.nbrp=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(n));


d=disponiblevol(p.r,p.nbrp);

if (d==1)
{
modif_resvol( p);
z.id=p.id;
 strcpy(z.type,"vol");
strcpy(z.login , p.login);
z.nbrp=p.nbrp;
 modif_res(z);
gtk_label_set_text(GTK_LABEL(output1),"place disponible");}
else 
gtk_label_set_text(GTK_LABEL(output1),"place indisponible");
 
gtk_widget_hide (modresv);


}


void
on_button102s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button104s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button105s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button106s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button107s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button108s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button109s_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview1rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1ajoutrec_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview1n_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *modifvol,*agent,*notebook1n;
GtkWidget *treeview1n;
GtkWidget *idn,*depn,*arrn,*prixn,*heuren,*typen,*jn,*mn,*an,*pn;


gchar *id,*dep,*arr,*heure,*type;
gint *j,*m,*a,*p,*prix;

agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
modifvol=create_modifvol();
treeview1n=lookup_widget(notebook1n,"treeview1n");

idn=lookup_widget(modifvol,"entrykh1");
depn=lookup_widget(modifvol,"entrykh2");
arrn=lookup_widget(modifvol,"entrykh3");
heuren=lookup_widget(modifvol,"entrykh4");
prixn=lookup_widget(modifvol,"entrykh5");
jn=lookup_widget(modifvol,"spinbuttonkh1");
mn=lookup_widget(modifvol,"spinbuttonkh2");
an=lookup_widget(modifvol,"spinbuttonkh3");
pn=lookup_widget(modifvol,"spinbuttonkh4");


typen=lookup_widget(modifvol,"comboboxentrykh1");
GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview1n));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&id,1,&dep,2,&arr,3,&j,4,&m,5,&a,6,&heure,7,&type,8,&prix,9,&p,-1);
	printf("%s %s %s %d %d %d %s %s %d %d",id,dep,arr,j,m,a,heure,type,prix,p);
	gtk_entry_set_text(GTK_ENTRY (idn),_(id));
	gtk_entry_set_text(GTK_ENTRY (depn),_(dep));
        gtk_entry_set_text(GTK_ENTRY (arrn),_(arr));
	gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
	gtk_entry_set_text(GTK_ENTRY (typen),_(type));
	gtk_entry_set_text(GTK_ENTRY (prixn),_(prix));
	
gtk_window_set_position(GTK_WINDOW(agent),GTK_WIN_POS_CENTER);
gtk_widget_show(modifvol);
}


void
on_button1n_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *agent;
GtkWidget *notebook1n;
GtkWidget *treeview1n;
agent=lookup_widget(button,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
treeview1n=lookup_widget(notebook1n,"treeview1n");
afficher3(treeview1n);
}


void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouvol,*agent,*notebook1n;
agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
ajouvol=create_ajouvol();
gtk_widget_show(ajouvol);
}


void
on_treeview2n_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *modifhotel,*agent,*notebook1n;
GtkWidget *treeview2n;
GtkWidget *idn,*lieun,*nomn,*prixn,*en,*pn,*chambren;
gchar *id,*lieu,*nom,*prix,*chambre;
gint *e,*p;

agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
modifhotel=create_modifhotel();
treeview2n=lookup_widget(notebook1n,"treeview2n");

idn=lookup_widget(modifhotel,"entry100n");
lieun=lookup_widget(modifhotel,"entry200n");
nomn=lookup_widget(modifhotel,"entry300n");
prixn=lookup_widget(modifhotel,"entry400n");
en=lookup_widget(modifhotel,"spinbutton100n");
pn=lookup_widget(modifhotel,"spinbutton200n");

chambren=lookup_widget(modifhotel,"comboboxentry100n");
GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview2n));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&id,1,&lieu,2,&nom,3,&e,4,&chambre,5,&prix,6,&p,-1);
	printf("%s %s %s %d %s %d %d",id,lieu,nom,e,chambre,prix,p);
	gtk_entry_set_text(GTK_ENTRY (idn),_(id));
	gtk_entry_set_text(GTK_ENTRY (lieun),_(lieu));
        gtk_entry_set_text(GTK_ENTRY (nomn),_(nom));
	gtk_entry_set_text(GTK_ENTRY (chambren),_(chambre));
	gtk_entry_set_text(GTK_ENTRY (prixn),_(prix));
	
gtk_window_set_position(GTK_WINDOW(agent),GTK_WIN_POS_CENTER);
gtk_widget_show(modifhotel);
}


void
on_button3n_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *agent;
GtkWidget *notebook1n;
GtkWidget *treeview2n;
 agent=lookup_widget(button,"agent");
 notebook1n=lookup_widget(agent,"notebook1n");
 treeview2n=lookup_widget(notebook1n,"treeview2n");
afficher2(treeview2n);
}


void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouhotel,*agent,*notebook1n;
agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
ajouhotel=create_ajouhotel();
gtk_widget_show(ajouhotel);
}


void
on_treeview3n_row_activated           (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *modifexcu,*agent,*notebook1n;
GtkWidget *treeview3n;
GtkWidget *idn,*desn,*progn,*prixn,*jn,*mn,*an,*pn;
gchar *id,*des,*prog;
gint *j,*m,*a,*pp,*prix;
agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
modifexcu=create_modifexcu();
treeview3n=lookup_widget(notebook1n,"treeview3n");
idn=lookup_widget(modifexcu,"entry5n");
desn=lookup_widget(modifexcu,"entry6n");
progn=lookup_widget(modifexcu,"entry7n");
prixn=lookup_widget(modifexcu,"entry8n");
jn=lookup_widget(modifexcu,"spinbutton5n");
mn=lookup_widget(modifexcu,"spinbutton6n");
an=lookup_widget(modifexcu,"spinbutton7n");
pn=lookup_widget(modifexcu,"spinbutton8n");
GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview3n));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&id,1,&des,2,&j,3,&m,4,&a,5,&prog,6,&prix,7,&pp,-1);
	printf("%s %s %d %d %d %s %d %d",id,des,j,m,a,prog,prix,pp);
	gtk_entry_set_text(GTK_ENTRY (idn),_(id));
	gtk_entry_set_text(GTK_ENTRY (desn),_(des));
        gtk_entry_set_text(GTK_ENTRY (progn),_(prog));
	gtk_entry_set_text(GTK_ENTRY (prixn),_(prix));
	
gtk_window_set_position(GTK_WINDOW(agent),GTK_WIN_POS_CENTER);
gtk_widget_show(modifexcu);
}

void
on_button5n_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *agent;
GtkWidget *notebook1n;
GtkWidget *treeview3n;
 agent=lookup_widget(button,"agent");
 notebook1n=lookup_widget(agent,"notebook1n");
 treeview3n=lookup_widget(notebook1n,"treeview3n");
afficher1(treeview3n);
}


void
on_button6n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouexcu,*agent,*notebook1n;
agent=lookup_widget(objet_graphique,"agent");
notebook1n=lookup_widget(agent,"notebook1n");
ajouexcu=create_ajouexcu();
gtk_widget_show(ajouexcu);
}



void
on_button8n_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouexcu;

     ajouexcu=lookup_widget(button,"ajouexcu");
     gtk_widget_hide(ajouexcu);
}


void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
excursion p;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *ajouexcu,*agent;
GtkWidget *nj,*nm,*na,*np;

input1= lookup_widget(objet_graphique,"entry1n");
input2= lookup_widget(objet_graphique,"entry2n");
input3= lookup_widget(objet_graphique,"entry3n");
input4= lookup_widget(objet_graphique,"spinbuttonnour");
ajouexcu= lookup_widget(objet_graphique,"ajouexcu");
agent= lookup_widget(objet_graphique,"agent");


nj=lookup_widget(objet_graphique,"spinbutton1n");
nm=lookup_widget(objet_graphique,"spinbutton2n");
na=lookup_widget(objet_graphique,"spinbutton3n");
np=lookup_widget(objet_graphique,"spinbutton4n");


p.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nj));
p.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nm));
p.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(na));
p.p=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(np));
p.prix=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));


strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.des,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prog,gtk_entry_get_text(GTK_ENTRY(input3)));
ajouter1(p);
gtk_widget_hide(ajouexcu);
}



void
on_button11n_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifexcu;
 GtkWidget *id,*des,*prog,*prix,*j,*m,*a,*pl;

excursion p;
  /* char idk[20],desk[20],progk[20],prixk[20];
	int jk,mk,ak,pk;*/
modifexcu=lookup_widget(button,"modifexcu");
   

id=lookup_widget(button,"entry5n");
 
des=lookup_widget(button,"entry6n");
prog=lookup_widget(button,"entry7n");
prix=lookup_widget(modifexcu,"spinbuttonnour1");


j=lookup_widget(modifexcu,"spinbutton5n");
m=lookup_widget(modifexcu,"spinbutton6n");
a=lookup_widget(modifexcu,"spinbutton7n");
pl=lookup_widget(modifexcu,"spinbutton8n");
	
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(p.des,gtk_entry_get_text(GTK_ENTRY(des)));
        strcpy(p.prog,gtk_entry_get_text(GTK_ENTRY(prog)));
	 p.prix = gtk_spin_button_get_value_as_int(pl);	
	p.j = gtk_spin_button_get_value_as_int(j);
        p.m = gtk_spin_button_get_value_as_int(m); 
	p.a = gtk_spin_button_get_value_as_int(a);
       p.p= gtk_spin_button_get_value_as_int(pl);	
	supprimer1(p);
gtk_widget_hide(modifexcu);
}


void
on_button10n_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifexcu;
 GtkWidget *id,*des,*prog,*prix,*j,*m,*a,*pl;
excursion p;
/*
   char idk[20],desk[20],progk[20],prixk[20];
	int jk,mk,ak,pk;*/
modifexcu=lookup_widget(button,"modifexcu");
   

id=lookup_widget(button,"entry5n");
 
des=lookup_widget(button,"entry6n");
prog=lookup_widget(button,"entry7n");
prix=lookup_widget(modifexcu,"spinbuttonnour1");


j=lookup_widget(modifexcu,"spinbutton5n");
m=lookup_widget(modifexcu,"spinbutton6n");
a=lookup_widget(modifexcu,"spinbutton7n");
pl=lookup_widget(modifexcu,"spinbutton8n");
	
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(p.des,gtk_entry_get_text(GTK_ENTRY(des)));
        strcpy(p.prog,gtk_entry_get_text(GTK_ENTRY(prog)));
	p.j = gtk_spin_button_get_value_as_int(j);
        p.m = gtk_spin_button_get_value_as_int(m); 
	p.a = gtk_spin_button_get_value_as_int(a);
       p.p = gtk_spin_button_get_value_as_int(prix);
	 p.prix = gtk_spin_button_get_value_as_int(pl);	
	modifier1(p);
gtk_widget_hide(modifexcu);
}


void
on_button9n_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifexcu;

     modifexcu=lookup_widget(button,"modifexcu");
     gtk_widget_hide(modifexcu);
}


void
on_button13nn_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouhotel;

     ajouhotel=lookup_widget(button,"ajouhotel");
     gtk_widget_hide(ajouhotel);
}


void
on_button12nn_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
hotel h;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *ajouhotel,*agent;
GtkWidget *ne,*np,*CHAMBRE;

input1= lookup_widget(objet_graphique,"entry1nn");
input2= lookup_widget(objet_graphique,"entry2nn");
input3= lookup_widget(objet_graphique,"entry3nn");
input4= lookup_widget(objet_graphique,"spinbuttonnour2");
ajouhotel= lookup_widget(objet_graphique,"ajouhotel");
agent= lookup_widget(objet_graphique,"agent");

CHAMBRE=lookup_widget(objet_graphique,"comboboxentry1nn");
ne=lookup_widget(objet_graphique,"spinbutton1nn");
np=lookup_widget(objet_graphique,"spinbutton2nn");



h.e=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(ne));
h.p=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(np));
h.prix=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));



strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.lieu,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambre,gtk_combo_box_get_active_text (GTK_COMBO_BOX(CHAMBRE)));
ajouter2(h);
gtk_widget_hide(ajouhotel);
}


void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifhotel;
GtkWidget *id,*lieu,*nom,*e,*chambre,*prix,*p;

hotel h;
  /* char idk[20],lieuk[20],chambrek[20],prixk[20],nomk[20];
	int ek,pk;*/
modifhotel=lookup_widget(objet_graphique,"modifhotel");
   

id=lookup_widget(objet_graphique,"entry100n");
 
lieu=lookup_widget(objet_graphique,"entry200n");
nom=lookup_widget(objet_graphique,"entry300n");
prix=lookup_widget(objet_graphique,"spinbuttonnour3");

e=lookup_widget(modifhotel,"spinbutton100n");
p=lookup_widget(modifhotel,"spinbutton200n");

	chambre=lookup_widget(modifhotel,"comboboxentry100n");
	strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(h.lieu,gtk_entry_get_text(GTK_ENTRY(lieu)));
        strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	 //strcpy(h.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
	strcpy(h.chambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(chambre)));
	h.e = gtk_spin_button_get_value_as_int(e);
	h.prix = gtk_spin_button_get_value_as_int(prix);
        h.p = gtk_spin_button_get_value_as_int(p); 
		
	supprimer2(h);
gtk_widget_hide(modifhotel);
}

void
on_button100n_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifhotel;

     modifhotel=lookup_widget(button,"modifhotel");
     gtk_widget_hide(modifhotel);
}


void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifhotel;
 GtkWidget *id,*lieu,*nom,*e,*chambre,*prix,*p;

hotel h;
   /*char idk[20],lieuk[20],chambrek[20],prixk[20],nomk[20];
	int ek,pk;*/
modifhotel=lookup_widget(objet_graphique,"modifhotel");
   

id=lookup_widget(objet_graphique,"entry100n");
 
lieu=lookup_widget(objet_graphique,"entry200n");
nom=lookup_widget(objet_graphique,"entry300n");
prix=lookup_widget(objet_graphique,"spinbuttonnour3");


e=lookup_widget(modifhotel,"spinbutton100n");
p=lookup_widget(modifhotel,"spinbutton200n");

	chambre=lookup_widget(modifhotel,"comboboxentry100n");
	strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(h.lieu,gtk_entry_get_text(GTK_ENTRY(lieu)));
        strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(h.chambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(chambre)));
	h.e = gtk_spin_button_get_value_as_int(e);
	h.prix = gtk_spin_button_get_value_as_int(prix);
        h.p = gtk_spin_button_get_value_as_int(p); 
		
	modifier2(h);
gtk_widget_hide(modifhotel);
}


void
on_button01n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
vol v;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *prix;
GtkWidget *ajouvol,*agent;
GtkWidget *nj,*nm,*na,*np,*TYPE;

input1= lookup_widget(objet_graphique,"entry01n");
input2= lookup_widget(objet_graphique,"entry02n");
input3= lookup_widget(objet_graphique,"entry03n");
input4= lookup_widget(objet_graphique,"entry04n");
prix=lookup_widget(objet_graphique,"spinbuttonnour4");
ajouvol= lookup_widget(objet_graphique,"ajouvol");
agent= lookup_widget(objet_graphique,"agent");

TYPE=lookup_widget(objet_graphique,"comboboxentry01n");
nj=lookup_widget(objet_graphique,"spinbutton01n");
nm=lookup_widget(objet_graphique,"spinbutton02n");
na=lookup_widget(objet_graphique,"spinbutton03n");
np=lookup_widget(objet_graphique,"spinbutton04n");



v.jv=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nj));
v.mv=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nm));
v.av=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(na));
v.pl=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(np));
v.prixv = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(prix));


strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.dep,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.arr,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.heure,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(v.type,gtk_combo_box_get_active_text (GTK_COMBO_BOX(TYPE)));
ajouter3(v);
gtk_widget_hide(ajouvol);
}

void
on_buttonkh3_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifvol;
GtkWidget *id,*dep,*arr,*j,*m,*a,*heure,*type,*prix,*p;


   vol v;
modifvol=lookup_widget(objet_graphique,"modifvol");
   

id=lookup_widget(objet_graphique,"entrykh1");
 
dep=lookup_widget(objet_graphique,"entrykh2");
arr=lookup_widget(objet_graphique,"entrykh3");
heure=lookup_widget(objet_graphique,"entrykh4");
prix=lookup_widget(objet_graphique,"entrykh5");


j=lookup_widget(modifvol,"spinbuttonkh1");
m=lookup_widget(modifvol,"spinbuttonkh2");
a=lookup_widget(modifvol,"spinbuttonkh3");
p=lookup_widget(modifvol,"spinbuttonkh4");
prix=lookup_widget(modifvol,"spinbuttonnour5");
	type=lookup_widget(modifvol,"comboboxentrykh1");
	strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(v.dep,gtk_entry_get_text(GTK_ENTRY(dep)));
        strcpy(v.arr,gtk_entry_get_text(GTK_ENTRY(arr)));
	strcpy(v.heure,gtk_entry_get_text(GTK_ENTRY(heure)));
	v.prixv = gtk_spin_button_get_value_as_int(prix);
	strcpy(v.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	v.jv = gtk_spin_button_get_value_as_int(j);
	v.mv = gtk_spin_button_get_value_as_int(m);
	v.av = gtk_spin_button_get_value_as_int(a);
        v.pl = gtk_spin_button_get_value_as_int(p); 
		
	supprimer3(v);
gtk_widget_hide(modifvol);
}


void
on_buttonkh2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifvol;
GtkWidget *id,*dep,*arr,*j,*m,*a,*heure,*type,*prix,*p;


   vol v;
modifvol=lookup_widget(objet_graphique,"modifvol");
   

id=lookup_widget(objet_graphique,"entrykh1");
 
dep=lookup_widget(objet_graphique,"entrykh2");
arr=lookup_widget(objet_graphique,"entrykh3");
heure=lookup_widget(objet_graphique,"entrykh4");



j=lookup_widget(modifvol,"spinbuttonkh1");
m=lookup_widget(modifvol,"spinbuttonkh2");
a=lookup_widget(modifvol,"spinbuttonkh3");
p=lookup_widget(modifvol,"spinbuttonkh4");
prix=lookup_widget(modifvol,"spinbuttonnour5");
	type=lookup_widget(modifvol,"comboboxentrykh1");
	strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(id)));
	strcpy(v.dep,gtk_entry_get_text(GTK_ENTRY(dep)));
        strcpy(v.arr,gtk_entry_get_text(GTK_ENTRY(arr)));
	strcpy(v.heure,gtk_entry_get_text(GTK_ENTRY(heure)));
	v.prixv = gtk_spin_button_get_value_as_int(prix);
	strcpy(v.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	v.jv = gtk_spin_button_get_value_as_int(j);
	v.mv = gtk_spin_button_get_value_as_int(m);
	v.av = gtk_spin_button_get_value_as_int(a);
        v.pl = gtk_spin_button_get_value_as_int(p); 
		
	modifier3(v);
gtk_widget_hide(modifvol);
}


void
on_buttonkh1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifvol;

     modifvol=lookup_widget(button,"modifvol");
     gtk_widget_hide(modifvol);
}




void
on_button1th_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *client,*notebook3;
GtkWidget *output1;
GtkWidget *output2;
client=lookup_widget(button,"client");
notebook3=lookup_widget(client,"notebook3");
output1=lookup_widget(client,"label1th");
output2=lookup_widget(client,"label2th");
gtk_label_set_text(GTK_LABEL(output1),"resevation confirmée");
char hh[10];
char d[10];
fact z;
int s;
FILE* f;
FILE* g;
s=0;
g=fopen("utilisateur.txt","r");
			fscanf(g,"%s",d);
			fclose(g);
f = fopen("facture.txt", "r");

 if(f==NULL)
	{
	 return;
	}		
 else 
	{
 	 f = fopen("facture.txt", "a+");
	 while(fscanf(f," %d %s %s %d\n",&z.id,z.type,z.login,&z.pf)!=EOF)
		{if (strcmp(d,z.login)==0)
		 s+=z.pf;
		}
	 fclose(f);
	 
	}
sprintf(hh,"%d",s);
gtk_label_set_text(GTK_LABEL(output2),hh);
}


void
on_button2th_enter                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

