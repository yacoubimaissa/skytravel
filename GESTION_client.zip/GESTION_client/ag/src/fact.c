#include <stdlib.h>
#include <stdio.h>
#include "nour.h"
#include "string.h"
#include <gtk/gtk.h>
/////////facturationvol//////////
void ajout_factvol_txt( factvol t )
{
FILE* f;
f=fopen("factvol.txt","a");
  if(f!=NULL)
   {
   fprintf(f,"%d %s %s %s %s %s %d %d %d %s %s %d %d %d\n",t.k.id,t.type,t.k.r.id,t.k.login,t.k.r.dep,t.k.r.arr,t.k.r.jv,t.k.r.mv,t.k.r.av,t.k.r.heure,t.k.r.type,t.k.r.prixv,t.k.nbrp,t.pf);
   }
fclose(f);
}

void ajout_facthot_txt( facthot t )
{
FILE* f;
f=fopen("facthot.txt","a");
  if(f!=NULL)
   {
   fprintf(f,"%d %s %s %s %s %s %d %s %d %d %d %d %d %d %d\n",t.k.id,t.type,t.k.r.id,t.k.login,t.k.r.lieu,t.k.r.nom,t.k.r.e,t.k.r.chambre,t.k.r.prix,t.k.j,t.k.m,t.k.a,t.k.nn,t.k.nbrp,t.pf);
   }
fclose(f);
}

void ajout_factexc_txt( factexc t )
{
FILE* f;
f=fopen("factexc.txt","a");
  if(f!=NULL)
   {
   fprintf(f,"%d %s %s %s %s %d %d %d %s %d %d %d\n",t.k.id,t.type,t.k.r.id,t.k.login,t.k.r.des,t.k.r.j,t.k.r.m,t.k.r.a,t.k.r.prog,t.k.r.prix,t.k.nbrp,t.pf);
   }
fclose(f);
}

void ajout_fact_txt( fact z)
{
FILE* f;
f=fopen("facture.txt","a");
  if(f!=NULL)
   {
   fprintf(f,"%d %s %s %d\n",z.id,z.type,z.login,z.pf);
   }
fclose(f);
}
enum   
{       
 
 ID,
 TYPE,
 LOGIN,
 PF,
COLUMNS
 
}; 

void afficher_facture(GtkWidget *liste)
{
 GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter    iter;
 GtkListStore *store;
fact z;
 store=NULL;
FILE* g;
 FILE* f;
char d[10];
  store=gtk_tree_view_get_model(liste);	
 if (store==NULL)
	{
	 renderer = gtk_cell_renderer_text_new ();
	 column = gtk_tree_view_column_new_with_attributes("identifiant", renderer,"text",ID, NULL);
	 gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

       

	 renderer = gtk_cell_renderer_text_new ();
	 column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",TYPE, NULL);
	 gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


         renderer = gtk_cell_renderer_text_new ();
	 column = gtk_tree_view_column_new_with_attributes("username", renderer, "text",LOGIN, NULL);
	 gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	 renderer = gtk_cell_renderer_text_new ();
	 column = gtk_tree_view_column_new_with_attributes("prix final", renderer, "text",PF, NULL);
	 gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 }


 store=gtk_list_store_new (COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
g=fopen("utilisateur.txt","r");
			fscanf(g,"%s",d);
			fclose(g);

f = fopen("facture.txt", "r");

 if(f==NULL)
	{
	 return;
	}		
 else 
	{
 	 f = fopen("facture.txt", "a+");
	 while(fscanf(f," %d %s %s %d\n",&z.id,z.type,z.login,&z.pf)!=EOF)
		{if (strcmp(d,z.login)==0)
		 {
			gtk_list_store_append (store, &iter);
		 	gtk_list_store_set (store,&iter,ID,z.id,TYPE,z.type,LOGIN,z.login,PF,z.pf,-1); }
		}
	 fclose(f);
	 gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	 g_object_unref (store);
	}

}

