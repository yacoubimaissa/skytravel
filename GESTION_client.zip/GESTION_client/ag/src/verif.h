typedef struct {
char log[30];
char pass[30];
int r;}users;
int verif( users u);
