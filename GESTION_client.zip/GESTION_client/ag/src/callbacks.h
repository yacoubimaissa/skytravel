#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button50i_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button2s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button3s_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button4s_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1ajoutrec_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1n_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1n_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2n_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button3n_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview3n_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5n_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8n_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11n_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10n_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9n_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13nn_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12nn_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button100n_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button01n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonkh3_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonkh2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonkh1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1s_row_activated            (GtkWidget     *objet_graphique,

                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button100s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button101s_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button102s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button104s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button105s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button106s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button107s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button108s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button109s_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1th_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2th_enter                     (GtkButton       *button,
                                        gpointer         user_data);
