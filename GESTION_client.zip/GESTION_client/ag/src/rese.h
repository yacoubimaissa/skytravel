#include <gtk/gtk.h>
typedef struct{
char id[50];
char des[50];
int j; 
int m;
int a;
char prog[50];
char prix[50];
int p;}excursion;
typedef struct {
char id[30];
char lieu[30];
char nom[30];
int e;
char chambre[30];
char prix[30]; 
int p;}hotel;
typedef struct {
char id[30];
char dep[30];
char arr[30];
int jv;
int mv;
int av;
char heure[30];
char type[30];
char prixv[30];
 int pl;}vol;


typedef struct{
 	int id;
        vol r;
	char login;
	int nbrp;
}resvol;

typedef struct{
 	int id;
        hotel r;
	char login;
	int nbrp;
}reshotel;

typedef struct{
 	int id;
        excursion r;
	char login ;
	int nbrp;
}resexc;
void ajout_resvol_txt(resvol p );
vol rechercheduvol(char id);
int genererid ();
